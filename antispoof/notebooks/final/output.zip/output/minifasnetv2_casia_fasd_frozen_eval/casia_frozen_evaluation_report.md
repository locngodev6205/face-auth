# Frozen MiniFASNetV2 evaluation — CASIA-FASD Kaggle image copy

This is the untouched external CASIA confirmation for the four CelebA-trained final 100K seed-100 models from Notebook 02 and 03. CASIA was not used for optimizer, CSMR lambda/gain, checkpoint, or threshold selection; no CASIA train data was used by this evaluation. LCC-FASD was external development, not untouched confirmation.

## Dataset and limits

The evaluated split is all `test_img/test_img/color` in `/kaggle/input/datasets/minhnh2107/casiafasd`: 2408 available JPEG frames, 360 reconstructed source-video IDs, 30 subjects numbered 1–30. This is not the official subject-disjoint CASIA benchmark. The Kaggle copy has 20 subjects, 240 video IDs, and 1403 frame identifiers shared between its train/test directories. The source videos are unavailable, so metrics concern only extracted frames.

Coverage: 352/360 videos; 2405/2405 planned frames detected. Video score is the mean of valid frame logit scores; at least 4 detections are required. Failures were never replaced.

No source face boxes are supplied. The detector selects the largest SCRFD box (confidence tie break); this fixed choice can pick an unintended face in a presentation attack. See detection coverage and box records.

## Frozen comparison

All four models received the identical ordered frames and cached SCRFD-500M/MiniFASNet crops. Each kept its own CelebA-Val logit threshold. CSMR was training-time only: ONNX inference has ordinary MiniFASNetV2 graphs and no FFT or spectral branch. Primary results are reconstructed video level.

| initialization   | method   |      auc |    apcer |    bpcer |     hter |   n_videos |
|:-----------------|:---------|---------:|---------:|---------:|---------:|-----------:|
| scratch          | vanilla  | 0.645059 | 0.162879 | 0.568182 | 0.36553  |        352 |
| scratch          | csmr     | 0.701963 | 0.132576 | 0.545455 | 0.339015 |        352 |
| pretrained       | vanilla  | 0.687758 | 0.238636 | 0.465909 | 0.352273 |        352 |
| pretrained       | csmr     | 0.710744 | 0.340909 | 0.272727 | 0.306818 |        352 |

Paired within-initialization CSMR minus Vanilla differences:

| initialization   |   delta_auc |   delta_apcer |   delta_bpcer |   delta_hter |
|:-----------------|------------:|--------------:|--------------:|-------------:|
| scratch          |   0.0569043 |     -0.030303 |    -0.0227273 |   -0.0265152 |
| pretrained       |   0.0229855 |      0.102273 |    -0.193182  |   -0.0454545 |

Subject-level paired bootstrap intervals estimate target-subject sampling uncertainty, not training-seed uncertainty or statistical significance. Only one training seed was evaluated. More seeds are outside this run. Frame, attack-type, and quality results are diagnostics. No overall model ranking or SOTA claim is made.

## Reproducibility

Detector SHA256: `5e4447f50245bbd7966bd6c0fa52938c61474a04ec7def48753668a9d8b4ea3a`. See `evaluation_protocol.json`, manifests, provenance, coverage, and prediction CSV files.
