# CASIA-FASD dataset exploration

Mounted root: `/kaggle/input/datasets/minhnh2107/casiafasd`
Files: 8126; images: 8126; videos: 0

## Observed split/modality counts

- test / color: 2408
- test / depth: 2408
- train / color: 1655
- train / depth: 1655

## Evaluation design questions

- Are these frame images or independent still-image samples? What original video/subject does each file belong to?
- What authoritative source maps filenames to Real/Attack, attack type, and quality?
- Does the explicit test folder correspond exactly to official subjects 21–50?
- Are color/depth files intended as pairs, and should only color enter the RGB model?

No official test video manifest or PAD labels were inferred by this notebook.
