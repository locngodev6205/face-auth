# MiniFASNetV2 5K hyperparameter screening

## Objective
Freeze one scratch LR, one pretrained LR pair, and one portable scratch-tuned CSMR lambda/gain recipe. One 5K/2K split and one seed are screening evidence only.

## Frozen nested resources
Tune Train5K / Val2K fingerprints: `{'tune_train5k': {'sample_count': 5000, 'class_counts': {'1': 2315, '0': 1637, '2': 1048}, 'ordered_sample_key_sha256': '52425728967f3a4e62b2915595a45a53886f07d646389a084884c65eefe7b659', 'source_manifest_sha256': '3ec46d1cc6b9bb384f244ba4fcc3657fd1e6f050b13b00b37818a913b590c8b6', 'sampling_seed': 43, 'file_sha256': '33142055672456ea95de978d8af0ebb8d14ae45d65a4d35117ac8eff21e3353f'}, 'tune_val2k': {'sample_count': 2000, 'class_counts': {'1': 922, '0': 656, '2': 422}, 'ordered_sample_key_sha256': '5ade0cea2cc0d339f4a6d7ac477c971ddc057bf1e27931b9219e6a568fd2ff7e', 'source_manifest_sha256': '5adf32016920e2e886e148eaedd6abdc73f092525c070ced2ca476c24326d4a9', 'sampling_seed': 43, 'file_sha256': '8368e1b20411174b0c783a42db0720b64dcd4a30ad4ba720e4e67b6f5afbf1bc'}}`. Resource hashes: `{'bundle_tree_sha256': 'f668bec7ba152124e0c2ec733286abde4dfc4dbe7e4918cd64448cddabb74022', 'tune_train_manifest_sha256': '33142055672456ea95de978d8af0ebb8d14ae45d65a4d35117ac8eff21e3353f', 'tune_val_manifest_sha256': '8368e1b20411174b0c783a42db0720b64dcd4a30ad4ba720e4e67b6f5afbf1bc', 'celeba_bbox_sha256': 'e15411af09c64581a7567c98e62b97df95bcfde2b3b5affa4af0761f8908ca28', 'lcc_manifest_sha256': 'b0d6927e0e509cbdacf452f9a8101aa963eb146f6070ff9496914cbec711ba50', 'lcc_bbox_sha256': 'd6508bde1c7f947ba7c995340c166bde9dee96b77794152a8bb51cbc56fcfbcf', 'minifasnet_source_sha256': 'e498c4ec5e1ddfaba62b941a126c19d65aa564999f3309661fe43ee8bf38acd7', 'official_checkpoint_sha256': 'a5eb02e1843f19b5386b953cc4c9f011c3f985d0ee2bb9819eea9a142099bec0'}`.

## Stage A — scratch Vanilla LR
```
candidate_name  backbone_lr  classifier_lr csmr_lambda gain_min gain_max  val_acer  val_auc  lcc_hter  lcc_auc eligible  selected reused_or_new
       lr_1e-4       0.0001         0.0001        None     None     None  0.141369 0.922916  0.407347 0.636794     None     False       NEW_RUN
       lr_3e-4       0.0003         0.0003        None     None     None  0.130099 0.934637  0.403960 0.630511     None     False       NEW_RUN
       lr_1e-3       0.0010         0.0010        None     None     None  0.110854 0.954003  0.392949 0.631663     None      True       NEW_RUN
```
Selected scratch LR: 0.001. Winner chosen by Tune-Val ACER then AUC; LCC did not choose optimizer LR.

## Stage B — pretrained Vanilla LR
```
candidate_name  backbone_lr  classifier_lr csmr_lambda gain_min gain_max  val_acer  val_auc  lcc_hter  lcc_auc eligible  selected reused_or_new
   candidate_0      0.00005         0.0005        None     None     None  0.024544 0.995155  0.272886 0.816983     None     False       NEW_RUN
   candidate_1      0.00010         0.0010        None     None     None  0.026704 0.996008  0.288000 0.820519     None     False       NEW_RUN
   candidate_2      0.00020         0.0010        None     None     None  0.022258 0.996322  0.304466 0.789718     None      True       NEW_RUN
```
Selected backbone/head LR: 0.0002 / 0.001. Released feature weights loaded; only prob.weight skipped and classifier replaced.

## Scratch Vanilla reference
Val ACER 0.110854, Val AUC 0.954003; LCC AUC 0.631663, HTER 0.392949.

## Stage C — CSMR lambda
```
candidate_name  backbone_lr  classifier_lr  csmr_lambda  gain_min  gain_max  val_acer  val_auc  lcc_hter  lcc_auc  eligible  selected reused_or_new
   lambda_0p10        0.001          0.001          0.1      0.65       0.9  0.103477 0.954865  0.436816 0.591472      True     False       NEW_RUN
   lambda_0p20        0.001          0.001          0.2      0.65       0.9  0.115246 0.945736  0.442453 0.617759      True      True       NEW_RUN
   lambda_0p40        0.001          0.001          0.4      0.65       0.9  0.107959 0.948550  0.472866 0.551824      True     False       NEW_RUN
```
Selected lambda: 0.2; Tune-Val ACER guard <= 0.120854.

## Stage D — gain severity
```
candidate_name  backbone_lr  classifier_lr  csmr_lambda  gain_min  gain_max  val_acer  val_auc  lcc_hter  lcc_auc  eligible  selected reused_or_new
          mild        0.001          0.001          0.2      0.75      0.95  0.102043 0.951024  0.449520 0.622664      True     False       NEW_RUN
       current        0.001          0.001          0.2      0.65      0.90  0.115246 0.945736  0.442453 0.617759      True     False        REUSED
        strong        0.001          0.001          0.2      0.55      0.85  0.116362 0.948381  0.415885 0.624053      True      True       NEW_RUN
```
Selected gain range: [0.55, 0.85]. An identical current-gain Stage-C run is reused.

## Frozen configuration
`frozen_hparams.json` SHA256 `2aedb0477c6d0ed05c9a96ba8918497b312fdebd0f820c1170e4c2b56398155e`. Scratch LR, pretrained LR recipe, CSMR lambda, and gain range are frozen for Notebook 01/02/03. One CSMR recipe is used unchanged for scratch and pretrained.

## Development-domain role
CelebA Tune-Val controls source checkpoint selection, threshold calibration, optimizer choice, and the CSMR source regression guard. LCC-FASD is an external-development robustness signal for CSMR selection; it is not an untouched final cross-domain test.

## Evaluation boundary
Frozen Test-5K was never evaluated during this search. CASIA-FASD remains untouched. Later Test/LCC numbers must not cause another hyperparameter search.

## Next step
Run Notebook 01 as 20K scale confirmation with this frozen configuration, then Notebook 02/03 without tuning.
