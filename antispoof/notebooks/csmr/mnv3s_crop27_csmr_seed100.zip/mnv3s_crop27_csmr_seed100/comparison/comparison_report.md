# MNV3-S 2.7x / 12-epoch CSMR seed-100 recipe comparison

## Protocol and interpretation
This practical recipe comparison changes both crop context (old 1.55x to 2.7x) and budget (old 6 to 12 epochs). It is not a pure architecture ablation or a crop-only causal test. MNV3-S uses ImageNet pretraining and 224x224 input; MiniFASNetV2 uses PAD pretraining and 80x80 input.

Frozen Stage-0 seed42 resource SHA `7c1eed4abaab7ee193758ea4bf4a0c36b98e43b5fb8d84c5c0e7d424607a0aa3`; 5,000 Train / 2,000 Val; training seed 100. Both current branches began at state SHA `2d662194c819df6ed15096842dcf37e4edef87769e4453769e746ba676030b92`. Crop uses the same frozen bbox/status records with a separate 2.7x adapter, RGB, 224x224 letterbox, and existing CelebA normalization.

## New paired Val/LCC results
| Metric | MNV3-S 2.7x Vanilla | MNV3-S 2.7x CSMR | Delta |
|---|---:|---:|---:|
| Val ACER | 0.021435 | 0.023377 | +0.001942 |
| Val AUC | 0.997905 | 0.997410 | -0.000496 |
| LCC APCER | 0.208123 | 0.101986 | -0.106137 |
| LCC BPCER | 0.557841 | 0.699229 | +0.141388 |
| LCC HTER | 0.382982 | 0.400608 | +0.017626 |
| LCC AUC | 0.675065 | 0.719440 | +0.044375 |

## Historical recipe comparison
| Recipe | Crop | Input | Pretraining | Val ACER | LCC HTER | LCC AUC |
|---|---:|---:|---|---:|---:|---:|
| MNV3-S new Vanilla | 2.7x | 224 | ImageNet | 0.021435 | 0.382982 | 0.675065 |
| MNV3-S new + CSMR | 2.7x | 224 | ImageNet | 0.023377 | 0.400608 | 0.719440 |
| MNV3-S old Vanilla/CSMR | 1.55x | 224 | ImageNet | NA | NA | NA |
| MiniFASNetV2 Vanilla | 2.7x | 80 | PAD pretrained | NA | NA | NA |
| MiniFASNetV2 + CSMR | 2.7x | 80 | PAD pretrained | NA | NA | NA |

## Questions
1. **Does the wider-context MNV3 recipe improve over old MNV3?** 
Undetermined until `OLD_MNV3_SUMMARY_PATH` points to the completed old summary. The current run also changes the budget from 6 to 12 epochs, so any difference cannot be attributed to crop alone.

2. **Does frozen CSMR still help MNV3-S at 2.7x?** CSMR-minus-Vanilla LCC AUC=+0.044375, LCC HTER=+0.017626, Val ACER=+0.001942. Positive AUC and negative HTER favor CSMR.

3. **Does MNV3-S 2.7x close the LCC gap to MiniFASNetV2 2.7x?** 
Undetermined until `MINIFASNET_SUMMARY_PATH` points to the completed MiniFASNetV2 transfer summary.

4. **Practical backbone candidate.** If MiniFASNetV2 remains better on both LCC AUC and HTER with references supplied, this supports choosing its current recipe as the practical final backbone candidate. This does not establish that architecture alone caused the difference.

## CSMR diagnostics
Final epoch LOW/MID/HIGH worst-view fractions: 0.163/0.389/0.448; harmful fraction=0.567; mean clean margin=27.467970114135742; mean worst margin=26.81790060119629; sampled gain=0.775; clip fraction=0.0095.

## Test-2000
Not evaluated in this cell. If both exact prior manifest and bbox-cache paths are configured, the next cell evaluates only those identities after Val/LCC summary persistence.

## Limits
One paired training seed. Old-to-new MNV3 comparison changes crop and epoch budget together. Cross-backbone comparison also changes architecture, input size, and pretraining. Historical summaries are reference-only; Test is descriptive and cannot affect selection.

## FIXED OPENED TEST-2000 DESCRIPTIVE BENCHMARK
Skipped because exact prior manifest and bbox-cache paths were not supplied.
